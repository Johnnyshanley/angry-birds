_accel = {}
_accel.x = 0;
_accel.y = 0;
_accel.z = 0;

function gotAccel(x, y, z){	
	_accel.x = x;	
	_accel.y = y;	
	_accel.z = z;
}

// use the var syntax eventually for namespace purposes

callbackStashCounter = 0;
callbackStash = {};

submitCallbackForExecution = function(callback) {
    var id = 'RaptorCB-' + (callbackStashCounter++);
    callbackStash[id] = callback;
    return id;
};

executeCallback = function(id) {
        if (id != null) {
            var callback = callbackStash[id];
            if (callback === null) {
                delete callbackStash[id];
                return 'executeCallback: id[' + id + '] received but callback entry does not exist';
            } else {
                if (typeof callback === 'function') {
                	callback();
                    delete callbackStash[id];
                    return 'executeCallback: Success';
                } else {
                    try {
                        eval(callback);
                    } catch(e) {
                        return 'executeCallback: Exception thrown: ' + e;
                    } finally {
                        delete callbackStash[id];
                    }
					
                    return 'executeCallback: Success';
                }
            }
        }
        return 'executeCallback: Invalid callback ID';
    }

var AdDevice = new Object();
AdDevice.transitions = {
        None          : 0,
        FlipFromLeft  : 1,
        FlipFromRight : 2,
        CurlUp        : 3,
        CurlDown      : 4
    };

AdDevice.getCurrentAcceleration = function (successCallback, errorCallback, options) {
	if (typeof successCallback == "function") {
		successCallback(_accel);	
	}
}

AdDevice.watchAcceleration = function (successCallback, errorCallback, options) {  
	var frequency = (options != undefined)? options.frequency : 10000;
	Accel.start(frequency);
	return setInterval(function() {
		AdDevice.getCurrentAcceleration(successCallback, errorCallback, options);
		}, frequency); 
}

AdDevice.clearWatch =  function (watchId) {	
	Accel.stop();	
	clearInterval(watchId);
}

AdDevice.beginAdInteraction = function () {
	Tracking.startInteraction();
}

AdDevice.endAdInteraction = function () {
	Tracking.stopInteraction();
}

AdDevice.expandTo = function (width, height, callback, transition, options) {
    var id = submitCallbackForExecution(callback);
    if (typeof transition !== 'number') {
        transition = AdDevice.transitions[transition];
        if (typeof transition === 'undefined') {
            transition = AdDevice.transitions.None;
        }
    }
    JtVwCb.expandTo(width, height, id, transition, options);
	AdDevice.beginAdInteraction();
}

AdDevice.restoreToBanner = function (callback, transition, options) {
    var id = submitCallbackForExecution(callback);
    if (typeof transition !== 'number') {
        transition = AdDevice.transitions[transition];
        if (typeof transition === 'undefined') {
            transition = AdDevice.transitions.None;
        }
    }
	JtVwCb.restoreToBanner(id, transition, options);
	AdDevice.endAdInteraction();
}

AdDevice.openURI = function(uri, contentType, options) {
	// TODO: do something
	// Tells the SDK to navigate to a specific URL and "do the right thing" with it.  
	// Since normally clicking on a link will be intercepted by the SDK, you'd use this 
	// function if you want to supply hints.  What hints, you say?  Well, contentType 
	// helps control what type of player will be chosen (or which external app will be used).  
	// This is particularly useful if the URI points to an URL-shortened URL and you want 
	// to tell the SDK what type of data will be at the other end of the redirect before the 
	// redirect is followed.  
	// (valid types are "youtube", "video", "uri", "tel", "itunes", "map")  
	// In this case, options is a JSON structure.  I think the only interesting option 
	// is fullscreen, as in {fullscreen: true}.
	JtVwCb.openURI(uri, contentType, options);
}

AdDevice.getScreenSize = function () {
	var response = JtVwCb.getScreenSize();
	var result = JSON.parse(response);
	return result;
}

function initORMMA() {
    var ormma = window.ormma = {};
    
    // CONSTANTS ///////////////////////////////////////////////////////////////
    
    var STATES = ormma.STATES = {
        UNKNOWN     :'unknown',
        DEFAULT     :'default',
        RESIZED     :'resized',
        EXPANDED    :'expanded',
        HIDDEN      :'hidden'
    };
    
    // just a subset of all ormma events
    var EVENTS = ormma.EVENTS = {
        ERROR               :'error',
        INFO                :'info',
        STATECHANGE         :'stateChange'
    };
    
    // PRIVATE PROPERTIES (sdk controlled) //////////////////////////////////////////////////////
    
    var state = STATES.UNKNOWN;
    
    var screenSize = null;
    
    var ready = false;
    
    var listeners = {};
    
    var EventListeners = function(event) {
        this.event = event;
        this.count = 0;
        var listeners = {};
        
        this.add = function(func) {
            var id = String(func);
            if (!listeners[id]) {
            	listeners[id] = func;
                this.count++;
                // if (this.count == 1) ormmaview.activate(event);
            }
        };
        this.remove = function(func) {
            var id = String(func);
            if (listeners[id]) {
            	listeners[id] = null;
                delete listeners[id];
                this.count--;
                // if (this.count == 0) ormmaview.deactivate(event);
                return true;
            } else {
            	return false;
            }
        };
        this.removeAll = function() { for (var id in listeners) this.remove(listeners[id]); };
        this.broadcast = function(args) { for (var id in listeners) listeners[id].apply({}, args); };
        this.toString = function() {
            var out = [event,':'];
            for (var id in listeners) out.push('|',id,'|');
            return out.join('');
        };
    };
    
    var contains = function(value, array) {
        for (var i in array) if (array[i] == value) return true;
        return false;
    };
    
    var broadcastEvent = function() {
        var args = new Array(arguments.length);
        for (var i = 0; i < arguments.length; i++) args[i] = arguments[i];
        var event = args.shift();
        if (listeners[event]) listeners[event].broadcast(args);
    }

    ormma.addEventListener = function(event, listener) {
        if (!event || !listener) {
            broadcastEvent(EVENTS.ERROR, 'Both event and listener are required.', 'addEventListener');
        } else if (!contains(event, EVENTS)) {
			broadcastEvent(EVENTS.ERROR, 'Unknown event: ' + event, 'addEventListener');
        } else {
            if (!listeners[event]) listeners[event] = new EventListeners(event);
            listeners[event].add(listener);
        }
    };

    ormma.removeEventListener = function(event, listener) {
        if (!event) {
            broadcastEvent(EVENTS.ERROR, 'Must specify an event.', 'removeEventListener');
        } 
        else {
            if (listener && (!listeners[event] || !listeners[event].remove(listener))) {
                broadcastEvent(EVENTS.ERROR, 'Listener not currently registered for event', 'removeEventListener');
                return;  
            } 
            else if (listeners[event]){
                listeners[event].removeAll();
            }
            
            if (listeners[event] && listeners[event].count == 0) {
                listeners[event] = null;
                delete listeners[event];
            }
        }
    };

   
    // todo: get the screen size via the bridge.
    // todo: presumably this is initialized once via javascript rather than
    // todo: invoked every time
    ormma.getScreenSize = function() { // return {width: 480, height: 320};
    	return AdDevice.getScreenSize();
    };
        
    // do nothing :-)
    ormma.getExpandProperties = function () { return {}; };
    // do nothing :-)
    ormma.setExpandProperties = function (props) { } ;
        
    // in a fully ORMMA compliant implementation this would be explicitly sent by the SDK whenever the
    // ad expands or contracts.  In our implementation, we want to support the ORMMA syntax for adding
    // and removing listeners but we only need the STATECHANGE event to be sent in response to an ORMMA
    // request to change state.
    ormma.runORMMAExpandCallbacks = function () { 
        state = STATES.EXPANDED;
        broadcastEvent(EVENTS.STATECHANGE, state);
    }
    ormma.runORMMACollapseCallbacks = function () { 
        state = STATES.DEFAULT;
        broadcastEvent(EVENTS.STATECHANGE, state);
    }
        
    ormma.expand = function(dimensions, URL) {
        // extract x,y,width,height from dimensions and pass off to 
        // AdDevice expander
        var width = dimensions.width;
        var height = dimensions.height;
        // todo: the callback here can be a noop because eventually the event triggering will
        // todo: automatically invoke the appropriate callbacks.
        AdDevice.expandTo(width, height, function() { ormma.runORMMAExpandCallbacks(); });
    };
        
    ormma.close = function() {
        AdDevice.restoreToBanner(function() { ormma.runORMMACollapseCallbacks();});
    };
        
    ormma.open = function(url, controls) {
        // TODO: handle controls
        AdDevice.openURI(url);
    };
    
    ormma.getViewable = function() {
    	return true;
    }
    
    ormma.hide = function() {
    	JtVwCb.hideWidget();
    }
        
    ormma.playVideo = function(url, properties) {
        // TODO: handle properties
        AdDevice.openURI(url);
    };

}

window.onload = initORMMA();
